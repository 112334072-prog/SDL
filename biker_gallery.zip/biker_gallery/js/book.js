/* ── Bike + rate from URL params ── */
const params = new URLSearchParams(window.location.search);
const BIKE   = params.get('bike') || 'Honda SP 125';
let   RATE   = parseInt(params.get('rate')) || 20;

document.getElementById('bikeTagName').textContent = BIKE;
document.getElementById('bikeTagRate').textContent = '₹' + RATE + '/hr';
document.getElementById('sumRate').textContent     = '₹' + RATE + '/hr';

const today = new Date().toISOString().split('T')[0];
document.getElementById('bookDate').min   = today;
document.getElementById('bookDate').value = today;
updateSummary();
document.getElementById('bookDate').addEventListener('change', updateSummary);

/* ── Field error helpers ── */
function showFE(id, msg) {
  const e = document.getElementById(id);
  if (e) { e.textContent = msg; e.classList.add('show'); }
}
function clearFE(id) {
  const e = document.getElementById(id);
  if (e) { e.textContent = ''; e.classList.remove('show'); }
}

/* ── Scope-out (blur) validation for all fields ── */
document.addEventListener('DOMContentLoaded', function () {

  /* Full Name — blur */
  document.getElementById('name').addEventListener('blur', function () {
    const v = this.value.trim();
    if (!v) {
      showFE('errName', 'Full name is required.');
      this.classList.add('invalid'); this.classList.remove('valid');
    } else if (v.length < 2) {
      showFE('errName', 'Name must be at least 2 characters.');
      this.classList.add('invalid'); this.classList.remove('valid');
    } else if (!/^[A-Za-z\s]+$/.test(v)) {
      showFE('errName', 'Name must contain only letters and spaces.');
      this.classList.add('invalid'); this.classList.remove('valid');
    } else {
      clearFE('errName');
      this.classList.remove('invalid'); this.classList.add('valid');
    }
  });

  /* Phone — blur */
  document.getElementById('phone').addEventListener('blur', function () {
    const v = this.value.trim();
    if (!v) {
      showFE('errPhone', 'Phone number is required.');
      this.classList.add('invalid'); this.classList.remove('valid');
    } else if (v.length < 10) {
      showFE('errPhone', 'Enter a valid 10-digit phone number.');
      this.classList.add('invalid'); this.classList.remove('valid');
    } else {
      clearFE('errPhone');
      this.classList.remove('invalid'); this.classList.add('valid');
    }
  });

  /* Date — blur */
  document.getElementById('bookDate').addEventListener('blur', function () {
    if (!this.value) {
      showFE('errDate', 'Please select a pickup date.');
      this.classList.add('invalid'); this.classList.remove('valid');
    } else {
      clearFE('errDate');
      this.classList.remove('invalid'); this.classList.add('valid');
    }
  });

  /* Live clear on input */
  document.getElementById('name').addEventListener('input', function () {
    if (this.value.trim().length >= 2 && /^[A-Za-z\s]+$/.test(this.value.trim())) {
      clearFE('errName'); this.classList.remove('invalid'); this.classList.add('valid');
    }
  });
  document.getElementById('phone').addEventListener('input', function () {
    if (this.value.trim().length >= 10) {
      clearFE('errPhone'); this.classList.remove('invalid'); this.classList.add('valid');
    }
  });
});

/* ── Check bike availability from DB on load ── */
async function checkAvailability() {
  try {
    const res    = await fetch('php/api_availability.php');
    const data   = await res.json();
    const status = data[BIKE] || 'available';

    if (status === 'booked') {
      const chip = document.getElementById('bikeTagAvail');
      if (chip) { chip.textContent = 'Unavailable'; chip.classList.add('tag-unavail'); }

      const btn = document.getElementById('confirmBtn');
      if (btn) {
        btn.textContent       = 'Bike Unavailable';
        btn.disabled          = true;
        btn.style.opacity     = '0.45';
        btn.style.cursor      = 'not-allowed';
        btn.style.pointerEvents = 'none';
        btn.style.background  = '#334155';
      }
      showErr('Sorry, this bike is currently unavailable. Please choose another from the menu.');
    }
  } catch(e) {
    console.warn('Availability check failed:', e);
  }
}
document.addEventListener('DOMContentLoaded', checkAvailability);

/* ── Stepper ── */
function changeH(d) {
  const inp = document.getElementById('hours');
  let v = parseInt(inp.value) + d;
  if (v < 1) v = 1;
  if (v > 24) v = 24;
  inp.value = v;
  updateSummary();
}

/* ── Summary calculator ── */
function updateSummary() {
  const h       = parseInt(document.getElementById('hours').value) || 1;
  const dateVal = document.getElementById('bookDate').value;
  document.getElementById('sumHours').textContent = h + (h === 1 ? ' hour' : ' hours');
  const base  = RATE * h;
  const gst   = Math.round(base * 0.18);
  const total = base + gst;
  document.getElementById('sumGST').textContent   = '₹' + gst;
  document.getElementById('sumTotal').textContent = '₹' + total;
  if (dateVal) {
    const d = new Date(dateVal);
    document.getElementById('sumDate').textContent =
      d.toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric' });
  }
}

/* ── Confirm booking ── */
async function confirmBooking() {
  const name  = document.getElementById('name').value.trim();
  const phone = document.getElementById('phone').value.trim();
  const date  = document.getElementById('bookDate').value;
  const h     = parseInt(document.getElementById('hours').value);
  const base  = RATE * h;
  const gst   = Math.round(base * 0.18);
  const total = base + gst;

  /* Final validation on submit */
  if (!name) {
    showFE('errName', 'Full name is required.');
    document.getElementById('name').classList.add('invalid');
    document.getElementById('name').focus(); return;
  }
  if (!/^[A-Za-z\s]+$/.test(name)) {
    showFE('errName', 'Name must contain only letters and spaces.');
    document.getElementById('name').classList.add('invalid');
    document.getElementById('name').focus(); return;
  }
  if (phone.length < 10) {
    showFE('errPhone', 'Enter a valid 10-digit phone number.');
    document.getElementById('phone').classList.add('invalid');
    document.getElementById('phone').focus(); return;
  }
  if (!date) {
    showFE('errDate', 'Please select a pickup date.');
    document.getElementById('bookDate').classList.add('invalid');
    return;
  }

  document.getElementById('errMsg').classList.remove('show');

  const btn = document.getElementById('confirmBtn');
  btn.disabled    = true;
  btn.textContent = 'Confirming…';

  try {
    const res  = await fetch('php/api_book.php', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ bike:BIKE, name, phone, date, hours:h, rate:RATE, gst, total })
    });
    const data = await res.json();

    if (data.success) {
      document.getElementById('successMsg').textContent =
        `${name}, your ${BIKE} is booked for ${h} hr(s) on ${document.getElementById('sumDate').textContent}. Total (incl. GST): ₹${total}`;
      document.getElementById('successOverlay').classList.add('visible');
    } else {
      showErr(data.msg || 'Booking failed. Please try again.');
      btn.disabled    = false;
      btn.textContent = 'Confirm Booking →';
    }
  } catch(e) {
    showErr('Network error. Please try again.');
    btn.disabled    = false;
    btn.textContent = 'Confirm Booking →';
  }
}

function showErr(msg) {
  const e = document.getElementById('errMsg');
  e.textContent = '⚠️ ' + msg;
  e.classList.add('show');
}