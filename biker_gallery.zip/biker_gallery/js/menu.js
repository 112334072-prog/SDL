function filter(cat, el) {
  document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
  el.classList.add('active');
  document.querySelectorAll('.bike-card').forEach(c => {
    c.style.display = (cat === 'all' || c.dataset.cat === cat) ? '' : 'none';
  });
  document.querySelectorAll('.category-heading').forEach(h => {
    h.style.display = (cat === 'all' || h.dataset.catHead === cat) ? '' : 'none';
  });
}

/* Load availability from DB and update all bike cards */
async function loadAvailability() {
  try {
    const res  = await fetch('php/api_availability.php');
    const data = await res.json();

    document.querySelectorAll('.bike-card').forEach(card => {
      const bikeName = card.querySelector('.bike-name')?.textContent?.trim();
      if (!bikeName) return;

      const status   = data[bikeName] || 'available';
      const chip     = card.querySelector('.avail-chip');
      const dot      = card.querySelector('.avail-dot');
      const bookBtn  = card.querySelector('.btn.btn-primary');

      if (status === 'booked') {
        /* Update chip */
        if (chip) {
          chip.innerHTML = '<span class="avail-dot unavail-dot"></span>Unavailable';
          chip.classList.add('unavail-chip');
        }
        /* Disable book button */
        if (bookBtn) {
          bookBtn.removeAttribute('href');
          bookBtn.classList.add('btn-disabled');
          bookBtn.textContent = 'Unavailable';
          bookBtn.style.pointerEvents = 'none';
          bookBtn.style.opacity = '0.45';
          bookBtn.style.cursor  = 'not-allowed';
          bookBtn.style.background = '#334155';
        }
        /* Grey out card */
        card.style.opacity = '0.75';
      } else {
        if (chip) {
          chip.innerHTML = '<span class="avail-dot"></span>Available';
          chip.classList.remove('unavail-chip');
        }
      }
    });
  } catch(e) {
    console.warn('Availability check failed:', e);
  }
}

document.addEventListener('DOMContentLoaded', loadAvailability);