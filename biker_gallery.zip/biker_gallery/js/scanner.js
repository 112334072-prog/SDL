/* ══════════════════════════════════════════
   Biker Gallery — scanner.js
   Uses Tesseract.js (free browser OCR)
   No API key required
   No scan limits
══════════════════════════════════════════ */

class KYCVerifier {
  constructor() {
    this.panData     = null;
    this.dlData      = null;
    this.worker      = null;
    this.workerReady = false;
    this._init();
  }

  async _initWorker() {
    if (this.workerReady) return;
    this.worker = await Tesseract.createWorker('eng', 1, { logger: () => {} });
    this.workerReady = true;
  }

  _init() {
    document.getElementById('panFile').addEventListener('change', e => this._handle(e, 'pan'));
    document.getElementById('dlFile').addEventListener('change',  e => this._handle(e, 'dl'));
  }

  async _handle(event, type) {
    const file = event.target.files[0];
    if (!file) return;
    if (type === 'pan') this.panData = null;
    else                this.dlData  = null;
    this._resetVerification();
    this._showPreview(file, type);
    await this._scan(file, type);
  }

  _showPreview(file, type) {
    const reader = new FileReader();
    reader.onload = e => {
      document.getElementById(`${type}Preview`).src = e.target.result;
      document.getElementById(`${type}Zone`).classList.add('has-image');
    };
    reader.readAsDataURL(file);
  }

  async _scan(file, type) {
    const chip   = document.getElementById(`${type}Chip`);
    const chipTx = document.getElementById(`${type}ChipText`);
    const result = document.getElementById(`${type}Result`);

    result.className = 'result-card';
    result.innerHTML = '';
    chip.classList.add('visible');
    chipTx.textContent = 'Loading OCR engine…';

    try {
      await this._initWorker();
      chipTx.textContent = 'Reading document text…';
      const { data: { text } } = await this.worker.recognize(file);
      chipTx.textContent = 'Extracting fields…';

      const parsed = type === 'pan' ? this._parsePAN(text) : this._parseDL(text);
      if (type === 'pan') this.panData = parsed;
      else                this.dlData  = parsed;

      this._showDocResult(type, parsed, text);
      this._autoFillIfReady();

    } catch (err) {
      result.className = 'result-card err visible';
      result.innerHTML = `<div class="rc-title">Scan Failed</div>
        <div>Could not read document. Upload a clear, well-lit photo.</div>
        <div style="font-size:11px;margin-top:4px;opacity:.7">${err.message}</div>`;
    } finally {
      chip.classList.remove('visible');
    }
  }

  _parsePAN(text) {
    const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
    let name = null, dob = null, id = null;

    const panMatch = text.match(/\b([A-Z]{5}[0-9]{4}[A-Z])\b/);
    if (panMatch) id = panMatch[1];

    const dobMatch = text.match(/(?:DOB|Date of Birth)[^0-9]*(\d{2}[\/\-]\d{2}[\/\-]\d{4})/i)
                  || text.match(/(\d{2}[\/\-]\d{2}[\/\-]\d{4})/);
    if (dobMatch) dob = this._normaliseDate(dobMatch[1]);

    const skip = new Set(['INCOME','TAX','DEPARTMENT','GOVT','GOVERNMENT','INDIA','PERMANENT','ACCOUNT','NUMBER','SIGNATURE']);
    for (const line of lines) {
      const cleaned = line.replace(/[^A-Z\s]/g,'').trim();
      const words   = cleaned.split(/\s+/).filter(Boolean);
      if (words.length < 2 || words.length > 5) continue;
      if (words.some(w => skip.has(w))) continue;
      if (!/^[A-Z\s]+$/.test(cleaned) || cleaned.length < 5) continue;
      name = cleaned; break;
    }
    return { name, dob, id };
  }

  _parseDL(text) {
    let name = null, dob = null, id = null;

    const dlMatch = text.match(/DL\s*No[.:)]*\s*([A-Z]{2}[\s\-]?\d{2}[\s\-\d]+)/i)
                 || text.match(/\b([A-Z]{2}\d{2}\s?\d{4,}\s?\d+)\b/);
    if (dlMatch) id = dlMatch[1].replace(/\s+/g,' ').trim();

    const dobMatch = text.match(/DOB\s*[:\-.]?\s*(\d{2}[\/\-]\d{2}[\/\-]\d{4})/i)
                  || text.match(/Date of Birth[:\s]*(\d{2}[\/\-]\d{2}[\/\-]\d{4})/i)
                  || text.match(/(\d{2}[\/\-]\d{2}[\/\-]\d{4})/);
    if (dobMatch) dob = this._normaliseDate(dobMatch[1]);

    const nameMatch = text.match(/Name\s*[:\.]?\s*([A-Z][A-Z\s]{3,})/i);
    if (nameMatch) {
      name = nameMatch[1].replace(/^(S\/O|D\/O|W\/O|S\/D\/W\s+of)\s*/i,'').replace(/\s+/g,' ').trim().toUpperCase();
    }
    return { name, dob, id };
  }

  _showDocResult(type, data, rawText) {
    const el    = document.getElementById(`${type}Result`);
    const label = type === 'pan' ? 'PAN Card' : 'Driving License';
    const idKey = type === 'pan' ? 'PAN No' : 'DL No&nbsp;';

    if (data.name || data.dob || data.id) {
      el.className = 'result-card ok visible';
      el.innerHTML = `<div class="rc-title">${label} scanned</div>
        ${data.name ? `<div class="rc-field">Name&nbsp;&nbsp; : ${data.name}</div>` : `<div class="rc-field" style="opacity:.5">Name : not detected</div>`}
        ${data.dob  ? `<div class="rc-field">DOB&nbsp;&nbsp;&nbsp; : ${data.dob}</div>`  : `<div class="rc-field" style="opacity:.5">DOB  : not detected</div>`}
        ${data.id   ? `<div class="rc-field">${idKey} : ${data.id}</div>` : ''}`;
    } else {
      el.className = 'result-card warn visible';
      el.innerHTML = `<div class="rc-title">Partial Read</div>
        <div>Fields not detected. Try a clearer, well-lit image.</div>
        <details style="margin-top:8px;cursor:pointer">
          <summary style="font-size:11px;opacity:.6">Show raw OCR text</summary>
          <pre style="font-size:10px;margin-top:6px;white-space:pre-wrap;opacity:.5">${rawText.slice(0,500)}</pre>
        </details>`;
    }
  }

  /* Auto-fill form fields from scanned doc */
  _autoFillIfReady() {
    const data = this.panData || this.dlData;
    if (!data) return;

    if (data.name) {
      const nameField = document.getElementById('full_name');
      if (nameField && !nameField.value) {
        nameField.value = data.name.slice(0, 35);
        if (typeof updateCounter === 'function') updateCounter('full_name', 'nameCount', 35);
      }
    }

    if (data.dob) {
      const dobField = document.getElementById('dob');
      if (dobField) {
        try {
          const [dd, mm, yyyy] = data.dob.split('/');
          const isoDate = `${yyyy}-${mm}-${dd}`;
          /* Temporarily allow writing by removing readonly, set, then re-add */
          dobField.removeAttribute('readonly');
          dobField.value = isoDate;
          dobField.setAttribute('readonly', true);
          /* Trigger DOB validation */
          if (typeof validateDOB === 'function') validateDOB(dobField);
        } catch(e) {}
      }
    }

    const banner = document.getElementById('verificationBanner');
    if (banner) {
      banner.className = 'visible ok';
      banner.innerHTML = `<div class="vb-header"><span class="vb-icon"></span><span>Document scanned — details auto-filled above</span></div>
        <div class="vb-body" style="font-size:13px;color:var(--muted);margin-top:4px;">You can edit the fields if anything was misread.</div>`;
    }
  }

  _resetVerification() {
    const banner = document.getElementById('verificationBanner');
    if (banner) { banner.className = ''; banner.innerHTML = ''; }
  }

  _normaliseDate(s) {
    if (!s) return '';
    let d = s.replace(/[-\.]/g, '/').trim();
    const iso = d.match(/^(\d{4})\/(\d{2})\/(\d{2})$/);
    if (iso) d = `${iso[3]}/${iso[2]}/${iso[1]}`;
    return d;
  }
}

document.addEventListener('DOMContentLoaded', () => new KYCVerifier());
