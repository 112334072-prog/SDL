<?php
/* ============================================================
   php/admin.php — Biker Gallery Admin Panel (Logic only)
   Fetches data from DB, then includes admin_panel.html for display.
   Lives in php/ subfolder → CSS: ../css/, links: ../
   ============================================================ */
session_start();

/* ── Disable browser caching — always fetch fresh data ── */
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

/* ── Admin session guard ── */
if (empty($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo "<script>window.location.replace('../login.html?msg=Please+login+as+admin');</script>";
    exit();
}

require_once 'db.php';

/* ── Handle POST: Mark bike as available ── */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['bike_name'])) {
    $bike = trim($_POST['bike_name']);
    if ($_POST['action'] === 'set_available') {
        $s = $conn->prepare("UPDATE menu SET availability='available' WHERE bike_name=?");
        $s->bind_param("s", $bike); $s->execute(); $s->close();

        $s = $conn->prepare(
            "UPDATE bookings SET status='returned'
             WHERE bike_name=? AND (status='active' OR status IS NULL)
             ORDER BY booked_at DESC LIMIT 1"
        );
        $s->bind_param("s", $bike); $s->execute(); $s->close();
    }
    header("Location: admin.php"); exit();
}

/* ── Fetch menu bikes & counts ── */
$menuBikes = [];
$res = $conn->query("SELECT bike_name, availability FROM menu ORDER BY id");
while ($row = $res->fetch_assoc()) {
    $menuBikes[$row['bike_name']] = $row['availability'];
}
$bookedCount    = count(array_filter($menuBikes, fn($v) => $v === 'booked'));
$availableCount = count(array_filter($menuBikes, fn($v) => $v === 'available'));

/* ── Fetch active bookings ── */
$activeBookings = [];
$res = $conn->query("SELECT * FROM bookings WHERE status='active' ORDER BY booked_at DESC");
if ($res && $res->num_rows > 0) {
    while ($row = $res->fetch_assoc()) $activeBookings[] = $row;
} else {
    $res2 = $conn->query("SELECT * FROM bookings ORDER BY booked_at DESC");
    if ($res2) while ($row = $res2->fetch_assoc())
        if (($menuBikes[$row['bike_name']] ?? '') === 'booked') $activeBookings[] = $row;
}

/* ── Fetch booking history ── */
$historyBookings = [];
$res = $conn->query("SELECT * FROM bookings WHERE status='returned' ORDER BY booked_at DESC");
if ($res && $res->num_rows > 0) {
    while ($row = $res->fetch_assoc()) $historyBookings[] = $row;
} else {
    $res2 = $conn->query("SELECT * FROM bookings ORDER BY booked_at DESC");
    if ($res2) while ($row = $res2->fetch_assoc())
        if (($menuBikes[$row['bike_name']] ?? '') === 'available') $historyBookings[] = $row;
}

/* ── Revenue calculations ── */
$all = array_merge($activeBookings, $historyBookings);
$base_total = $grand_total = 0;
foreach ($all as $b) {
    $base_total  += $b['rate'] * $b['hours'];
    $grand_total += $b['total'];
}
$cgst = round($base_total * 0.09);

$conn->close();

/* ── Load the HTML view ── */
include __DIR__ . '/admin_panel.html';
