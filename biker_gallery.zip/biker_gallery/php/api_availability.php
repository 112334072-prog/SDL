<?php
/* ============================================================
   php/api_availability.php — Biker Gallery
   MERGED FILE:
     GET  → returns all bike availabilities as JSON
     POST → updates one bike's availability
   ============================================================ */
require_once 'db.php';
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $bike   = trim($_POST['bike_name'] ?? '');
    $action = trim($_POST['action']    ?? '');

    if (!$bike || !in_array($action, ['set_available', 'set_booked'])) {
        echo json_encode(['success' => false, 'msg' => 'Invalid request']);
        exit();
    }
    $status = ($action === 'set_available') ? 'available' : 'booked';
    $stmt   = $conn->prepare("UPDATE menu SET availability=? WHERE bike_name=?");
    $stmt->bind_param("ss", $status, $bike);
    $stmt->execute();
    $stmt->close();
    $conn->close();
    echo json_encode(['success' => true, 'msg' => 'Updated']);
    exit();
}

/* GET — return all availabilities */
$result = $conn->query("SELECT bike_name, availability FROM menu ORDER BY id");
$bikes  = [];
while ($row = $result->fetch_assoc()) {
    $bikes[$row['bike_name']] = $row['availability'];
}
$conn->close();
echo json_encode($bikes);
