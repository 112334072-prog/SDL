<?php
/* ============================================================
   php/api_book.php — Biker Gallery
   Saves booking (status='active') + marks bike as booked
   ============================================================ */
require_once 'db.php';
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$data  = json_decode(file_get_contents('php://input'), true);
$bike  = trim($data['bike']  ?? '');
$name  = trim($data['name']  ?? '');
$phone = trim($data['phone'] ?? '');
$date  = trim($data['date']  ?? '');
$hours = intval($data['hours'] ?? 1);
$rate  = intval($data['rate']  ?? 0);
$gst   = intval($data['gst']   ?? 0);
$total = intval($data['total'] ?? 0);

if (!$bike || !$name || !$phone || !$date) {
    echo json_encode(['success' => false, 'msg' => 'Missing required fields']);
    exit();
}

/* Check bike still available */
$stmt = $conn->prepare("SELECT availability FROM menu WHERE bike_name = ? LIMIT 1");
$stmt->bind_param("s", $bike);
$stmt->execute();
$res = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$res || $res['availability'] === 'booked') {
    echo json_encode(['success' => false, 'msg' => 'Bike is already booked']);
    exit();
}

/* Try insert with status column first */
$ok = false;
$stmt = $conn->prepare(
    "INSERT INTO bookings (bike_name,customer_name,phone,pickup_date,hours,rate,gst,total,status)
     VALUES (?,?,?,?,?,?,?,?,'active')"
);
if ($stmt) {
    $stmt->bind_param("ssssiiii", $bike, $name, $phone, $date, $hours, $rate, $gst, $total);
    $ok = $stmt->execute();
    $stmt->close();
}
if (!$ok) {
    /* Fallback without status column */
    $stmt2 = $conn->prepare(
        "INSERT INTO bookings (bike_name,customer_name,phone,pickup_date,hours,rate,gst,total)
         VALUES (?,?,?,?,?,?,?,?)"
    );
    $stmt2->bind_param("ssssiiii", $bike, $name, $phone, $date, $hours, $rate, $gst, $total);
    $stmt2->execute();
    $stmt2->close();
}

/* Mark bike as booked */
$stmt = $conn->prepare("UPDATE menu SET availability='booked' WHERE bike_name=?");
$stmt->bind_param("s", $bike);
$stmt->execute();
$stmt->close();

$conn->close();
echo json_encode(['success' => true, 'msg' => 'Booking confirmed']);
